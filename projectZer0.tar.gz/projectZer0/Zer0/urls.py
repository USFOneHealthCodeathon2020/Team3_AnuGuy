from django.urls import path
from . import views

urlpatterns = [
        path('', views.home, name='Zer0-home'),
        path('content', views.content,name='Zer0-content'),

]

