from django.apps import AppConfig


class Zer0Config(AppConfig):
    name = 'Zer0'
