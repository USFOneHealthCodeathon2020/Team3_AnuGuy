from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.core.files.storage import FileSystemStorage

def home(request):

    return render(request, 'Zer0/home.html',{'title':'Microbiome Data Bank'}) 

def content(request):

    return render(request, 'Zer0/content.html',{'title':'Microbiome Content'})

def upload(request):
    if request.method == 'POST':
        uploaded_file = request.FILES['document']
        print(uploaded_file.name)
        print(uploaded_file.size)
        fs = FileSystemStorage()
        fs.save(uploaded_file.name,uploaded_file)

    return render(request, 'Zer0/upload_content.html',{'title':'FileUpload'})

