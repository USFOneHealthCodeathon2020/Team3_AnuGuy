from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required

def home(request):

    return render(request, 'Zer0/home.html',{'title':'Microbiome Data Bank'}) 

def content(request):

    return render(request, 'Zer0/content.html',{'title':'Microbiome Content'}
    
)
